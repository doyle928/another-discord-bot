const fetch = require("node-fetch");

module.exports = async (client, guild) => {
  // let guildId = guild.id.toString();
  // let query = `mutation {
  //     deleteServer(serverId: ${guildId}) {
  //       server_id
  //     }
  //   }`;
  // try {
  //   let res = await fetch("http://localhost:3000", {
  //     method: "PUT",
  //     headers: {
  //       "Content-Type": "application/json",
  //       Accept: "application/json"
  //     },
  //     body: JSON.stringify({
  //       query
  //     })
  //   });
  //   let data = await res.json();
  //   console.log("data: ", data);
  // } catch (err) {
  //   console.error(err);
  // }
};
