let defaultIds = {
  guild: "542945080495833119",
  channel: "542945080495833121",
  mod: "561372938474094603"
};

module.exports = defaultIds;
