const { gql } = require("apollo-server");

module.exports = gql`
  type User {
    guild_id: String!
    user_id: String!
    join_date: String!
    strikes: Int
  }
  type Count {
    guild_id: String!
    members: Int!
    timestamp: String!
  }
  type Server {
    guild_id: String!
  }
  type Default {
    guild_id: String!
    channel_id: String!
    mod_channel_id: String!
    user_id: String!
  }
  type Message {
    guild_id: String!
    channel_id: String!
    channel_name: String!
    message_count: Int!
    day: String!
  }
  type Query {
    getUser(guild_id: String!, user_id: String!): User!
    getUsers: [User]
    getCount(guild_id: String!): [Count]
    getCounts: [Count]
    getServers: [Server]
    getDefaults: [Default]
    getMessages(guild_id: String!): [Message]
    getMessage(guild_id: String!, channel_id: String!, day: String!): Message!
  }
  type Mutation {
    addUser(
      guild_id: String!
      user_id: String!
      join_date: String!
      strikes: Int!
    ): User!
    addStrike(guild_id: String!, user_id: String!, strikes: Int): User!
    addCount(guild_id: String!, members: Int!, timestamp: String!): Count!
    addServer(guild_id: String!): Server!
    setDefault(
      guild_id: String!
      channel_id: String!
      mod_channel_id: String!
      user_id: String!
    ): Default
    addMessage(
      guild_id: String!
      channel_id: String!
      channel_name: String!
      message_count: Int!
      day: String!
    ): Message!
    updateMessage(
      guild_id: String!
      channel_id: String!
      channel_name: String!
      message_count: Int
      day: String!
    ): Message!
  }
`;
